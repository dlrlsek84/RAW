package com.example.raw;

import android.webkit.WebView;

/**
 * Created by 영남 on 2016-11-16.
 */

public class WebClient extends Remote {
        public boolean shouldOverrideUrlLoading(WebView webView, String url){
            webView.loadUrl(url);
            return true;
        }
    }