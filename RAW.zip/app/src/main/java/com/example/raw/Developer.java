package com.example.raw;

import android.os.Bundle;

/**
 * Created by 영남 on 2016-11-16.
 */

public class Developer extends MainActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.developer);

    }
}
