package com.example.raw;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

    public class Testcapture extends MainActivity {
        View capView;
        /**
         * Called when the activity is first created.
         */
        @Override

        public void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);

            setContentView(R.layout.remote);

 /*           Button bt_capture = (Button) findViewById(R.id.bt_capture);

            LinearLayout ly_main = (LinearLayout) findViewById(R.id.ly_main);

            bt_capture.setOnClickListener(mClickListener);

            capView = ly_main;  // 리니어 레이아웃 캡춰

//        capView = getWindow().getDecorView();  // 전체 화면 캡춰
*/

        }

        View.OnClickListener mClickListener = new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                switch (v.getId()) {

                    case R.id.bt_capture:

                        try {

                            screenshot(capView);

                        } catch (Exception e) {

                            // TODO Auto-generated catch block

                            e.printStackTrace();
                        }
                        break;

                    default:

                        break;

                }

            }

        };

            public void screenshot (View view) throws Exception{

                view.setDrawingCacheEnabled(true);

                Bitmap screenshot = view.getDrawingCache();

                String filename = "screenshot123.png";

                try{

                    File f = new File(Environment.getExternalStorageDirectory(),filename);

                    f.createNewFile();

                    OutputStream outStream = new FileOutputStream(f);

                    screenshot.compress(Bitmap.CompressFormat.PNG, 100, outStream);

                    outStream.close();

                }catch( IOException e){

                    e.printStackTrace();
                }
                view.setDrawingCacheEnabled(false);
            }
        }