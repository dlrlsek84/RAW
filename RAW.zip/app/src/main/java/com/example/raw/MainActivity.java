package com.example.raw;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

//import android.os.Handler;
//import android.util.Log;

public class MainActivity extends AppCompatActivity {


    //back 2번 -> exit
    private BackPressCloseHandler backPressCloseHandler;
    //
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 위 소스 아래부분에  splash.class 호출 -- 추가
        startActivity(new Intent(this,IntroActivity.class));

        //back 2번 -> exit
        backPressCloseHandler = new BackPressCloseHandler(this);
        //

       // Button button1 = (Button) findViewById(button01);
       // button1.setOnClickListener(new View.OnClickListener() {
       //     @Override
       //     public void onClick(View v) {
       //         Toast.makeText(getApplicationContext(),"Remote----",
        //                Toast.LENGTH_LONG).show();
         //       setContentView(R.layout.activity_main);
         //   }
        //}); // 클릭시 화면에 Remote---- 표시

  //      Button button01 = (Button) findViewById(R.id.button01);
      //  button1.setOnClickListener(new View.OnClickListener(){
      //      @Override
      //      public void onClick(View v){
      //          Intent intent = new Intent(getApplicationContext(), Remote.class);
      //          startActivity(intent);
      //      }
      //  }); // Remote view 로 이동

        /**      Button button3 = (Button) findViewById(button03);
         button3.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
        Toast.makeText(getApplicationContext(),"Homepage going----",
        Toast.LENGTH_LONG).show();
        setContentView(R.layout.activity_main);
        });


        }**/

    //    Button button4 = (Button) findViewById(button04);
    //    button4.setOnClickListener(new View.OnClickListener() {
    //        @Override
    //        public void onClick(View v) {
    //            Toast.makeText(getApplicationContext(),"Developer----",
    //                    Toast.LENGTH_LONG).show();
    //            setContentView(R.layout.activity_main);
    //        }
    //    }); // 클릭시 화면에 Developer---- 표시

       // Button button4 = (Button) findViewById(R.id.button04);

       // button4.setOnClickListener(new View.OnClickListener(){
       //     @Override
       //     public void onClick(View v){
       //         Intent intent = new Intent(getApplicationContext(), Developer.class);
       //         startActivity(intent);
       //     }
       // }); // Remote view 로 이동

    }
    //back 2번 -> exit
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        backPressCloseHandler.onBackPressed();
    }
    //
    public void remote(View v){
        Toast.makeText(getApplicationContext(),"Remote----",
                Toast.LENGTH_LONG).show();
        Intent intent = new Intent(getApplicationContext(), Remote.class);
        startActivity(intent);
        //setContentView(R.layout.remote);
    }

    public void homepage(View v){
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://qjarl85.cafe24.com")));
    //    Button button3 = (Button) findViewById(R.id.button03); //OnClick 삭제
    }
    public void developer(View v){
        Toast.makeText(getApplicationContext(),"Developer----",
                Toast.LENGTH_LONG).show();
       // setContentView(R.layout.activity_main);
        setContentView(R.layout.developer);

    }
    private int REQ_PICK_CODE=100;
    public void gallery(View v){
        Intent pickerIntent = new Intent(Intent.ACTION_PICK);
        pickerIntent.setType(android.provider.MediaStore.Images.Media.CONTENT_TYPE);
        pickerIntent.setData(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(pickerIntent, REQ_PICK_CODE);
    }
    public void menu(View v){
        setContentView(R.layout.activity_main);
    }
}
