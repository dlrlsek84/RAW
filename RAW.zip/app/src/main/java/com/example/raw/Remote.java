package com.example.raw;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;


/**
 * Created by 영남 on 2016-11-16.
 */

public class Remote extends MainActivity {

    //AsyncTask - tcp 세팅
    public static Socket socket= null;

    static TextView recieveText;
    static  EditText editTextAddress, editTextPort, messageText;
    static Button connectBtn, clearBtn,dtop,dbottom,dright,dleft;
    //
    WebView mWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.remote);

        Button button05 = (Button) findViewById(R.id.button5);
        button05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

     /*   WebView webView = (WebView)findViewById(R.id.webView);
        webView.setWebViewClient(new WebViewClient());
        webView.setBackgroundColor(255);

        //영상을 폭에 꽉 차게 할려고 했지만 먹히지 않음???
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        //이건 최신 버전에서는 사용하지 않게됨
        //webView.getSettings().setDefaultZoom(WebSettings.ZoomDensity.FAR);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        //영상을 폭을 꽉 차게 하기 위해 직접 html태그로 작성함.
    //    webView.loadData("<html><head><style type='text/css'>body{margin:auto auto;text-align:center;} img{width:100%25;} div{overflow: hidden;} </style></head><body><div><img src='http://192.168.0.139:8080/stream/video.mjpeg'/></div></body></html>" ,"text/html",  "UTF-8");
        webView.loadUrl("http://192.168.0.139:8080/stream/video.mjpg");
        webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.clearCache(true);
        webView.getSettings().setAppCacheEnabled(false);
*/
 /*       setContentView(R.layout.remote); // 레이아웃 가져오기
        WebView webView = (WebView) findViewById(R.id.webView);// id 매칭
        webView.setWebViewClient(new WebViewClient());// 방금전에 만든 웹뷰 webView 의 WebViewClient 를 설정
        WebSettings set = webView.getSettings();// 웹뷰의 기본설정을 가져옵니다.
        set.setJavaScriptEnabled(true); //자바스크립트 허용

        webView.loadUrl("http://192.168.0.139:8080/stream/video.mjpg"); //주소
   */

        mWebView = (WebView) findViewById(R.id.webView);
        mWebView.loadUrl("http://192.168.43.157:8080/stream"); // 와이파이 변경시 변경- 리눅스 ifconfig 확인
        mWebView.setWebViewClient(new BlogWebViewClient());
        mWebView.getSettings().setJavaScriptEnabled(true);


        //앱 기본 스타일 설정
        getSupportActionBar().setElevation(0);

        connectBtn = (Button) findViewById(R.id.buttonConnect);
        clearBtn = (Button) findViewById(R.id.buttonClear);
        editTextAddress = (EditText) findViewById(R.id.addressText);
        editTextPort = (EditText) findViewById(R.id.portText);
        recieveText = (TextView) findViewById(R.id.textViewReciev);
        messageText = (EditText) findViewById(R.id.messageText);

        //connect 버튼 클릭
        connectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //         editTextAddress.setText("192.168.0.113");
                //         editTextPort.setText("8080");
                //         messageText.setText("right");
                Toast.makeText(getApplicationContext(),"Connect---", Toast.LENGTH_LONG).show();
                MyClientTask myClientTask = new MyClientTask(editTextAddress.getText().toString(), Integer.parseInt(editTextPort.getText().toString()), messageText.getText().toString());
                myClientTask.execute();
                //messageText.setText("");
            }
        });

        //clear 버튼 클릭
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Clear---", Toast.LENGTH_LONG).show();
                recieveText.setText("");
                messageText.setText("");
            }
        });
        /*
        //top 버튼 클릭
        dtop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                messageText.setText("top");

                //   messageText.setText("top");
            }
        });
        //right 버튼 클릭
        dbottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                messageText.setText("bottom");

                //  messageText.setText("bottom");
            }
        });
        //right 버튼 클릭
        dleft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                messageText.setText("left");

                //messageText.setText("left");
            }
        });
        //right 버튼 클릭
        dright.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                messageText.setText("right");

                // messageText.setText("right");
            }
        });
*/ //REMOTE 내용


    }
    //
    public class MyClientTask extends AsyncTask<Void, Void, Void> {
        String dstAddress;
        int dstPort;
        String response = "";
        String myMessage = "";

        //constructor
        MyClientTask(String addr, int port, String message){
            dstAddress = addr;
            dstPort = port;
            myMessage = message;
        }

        @Override
        protected Void doInBackground(Void... arg0) {

            // Socket socket = null;
            myMessage = myMessage.toString();
            try {
                socket = new Socket(dstAddress, dstPort);
                //송신
                OutputStream out = socket.getOutputStream();
                out.write(myMessage.getBytes());

                //수신
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
                byte[] buffer = new byte[1024];
                int bytesRead;
                InputStream inputStream = socket.getInputStream();
    /*
     * notice:
     * inputStream.read() will block if no data return
     */
                while ((bytesRead = inputStream.read(buffer)) != -1){
                    byteArrayOutputStream.write(buffer, 0, bytesRead);
                    response += byteArrayOutputStream.toString("UTF-8");
                }
                response = "서버의 응답: " + response;

            } catch (UnknownHostException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response = "UnknownHostException: " + e.toString();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response = "IOException: " + e.toString();
            }finally{
                if(socket != null){
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            recieveText.setText(response);
            super.onPostExecute(result);
        }

    }

    private class BlogWebViewClient extends  WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url){
            view.loadUrl(url);
            return true;
        }
    }
}